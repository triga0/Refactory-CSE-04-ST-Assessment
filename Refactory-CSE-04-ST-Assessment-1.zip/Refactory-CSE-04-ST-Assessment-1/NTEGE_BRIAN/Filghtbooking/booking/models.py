from django.db import models
from django.core.exceptions import ValidationError
from django.core.validators import MinLengthValidator
from django.utils.translation import gettext_lazy as _
from datetime import date
import re

# Create your models here.

def validate_age(value):
    if value < 18:
       raise ValidationError(_('Age must be at least 18.'))
    if value > 99:
       raise ValidationError(_('Age must be less than or equal to 99.'))
    return value


def validate_letters(value):
    if not re.match(r"^[a-zA-Z]+\s*[a-zA-Z]+$", value):

       raise ValidationError('Name must contain only letters.')
    return value


class Passenger(models.Model):
    full_name = models.CharField(max_length=100)
    gender = models.CharField(max_length=10)
    date_of_birth = models.DateField()
    nationality = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=15)
    email = models.EmailField()
    po_box = models.CharField(max_length=100, blank=True, null=True)
    emergency_phone_number = models.CharField(max_length=15)
    passport_number = models.CharField(max_length=20)
    visa_document = models.FileField(upload_to='visas/', blank=True, null=True)
    departure_city = models.CharField(max_length=50)
    destination = models.CharField(max_length=50)
    
    
    class Passenger(models.Model):
        photo = models.ImageField(upload_to='photos/', blank=True, null=True)  # Add photo upload


def _str_(self):
    
        return self.full_name