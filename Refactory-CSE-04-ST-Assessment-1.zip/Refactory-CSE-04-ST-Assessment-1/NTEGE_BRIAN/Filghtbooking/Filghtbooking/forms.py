this is forms.pyfrom django import forms
from .models import Passenger
from django.core.validators import RegexValidator

class PassengerForm(forms.ModelForm):
    # Customizing the phone number fields with regex for validation
    phone_number = forms.CharField(
        max_length=15,
        validators=[
            RegexValidator(
                regex=r'^\+?\d{9,15}$',
                message="Phone number must be in the format '+999999999'. Up to 15 digits allowed."
            )
        ],
        widget=forms.TextInput(attrs={'placeholder': 'Enter phone number'})
    )
    emergency_phone_number = forms.CharField(
        max_length=255,
        validators=[
            RegexValidator(
                regex=r'^\+?\d{9,15}$',
                message="Emergency phone number must be in the format '+999999999'. Up to 15 digits allowed."
            )
        ],
        widget=forms.TextInput(attrs={'placeholder': 'Enter emergency phone number'})
    )
    
    class Meta:
        model = Passenger
        fields = '_all_'

        widgets = {
            'Full_name': forms.TextInput(attrs={'placeholder': 'Enter full name'}),
            'Gender': forms.Select(choices=[('Male', 'Male'), ('Female', 'Female')]),
            'Date_of_birth': forms.DateInput(attrs={'type': 'date'}),
            'Nationality': forms.TextInput(attrs={'placeholder': 'Enter nationality'}),
            'Email': forms.EmailInput(attrs={'placeholder': 'Enter email address'}),
            'P.O.Box': forms.TextInput(attrs={'placeholder': 'Enter PO Box (Optional)'}),
            'Passport_number': forms.TextInput(attrs={'placeholder': 'Enter passport number'}),
            'Departure_city': forms.TextInput(attrs={'placeholder': 'Enter departure city'}),
            'Destination_city': forms.TextInput(attrs={'placeholder': 'Enter destination'}),
        }